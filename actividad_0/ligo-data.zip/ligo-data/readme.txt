Series de datos tomadas de:
https://www.ligo.caltech.edu/page/ligo-data
-
Asignación de datos por grupo
-
grupo 01 -> G-G1_GWOSC_4KHZ_R1-1187008867-32.txt.gz
grupo 02 -> H-H1_GWOSC_4KHZ_R1-1126259447-32.txt.gz
grupo 03 -> H-H1_GWOSC_4KHZ_R1-1186741846-32.txt.gz
grupo 04 -> H-H1_GWOSC_4KHZ_R1-1187008867-32.txt.gz
grupo 05 -> H-H1_GWOSC_4KHZ_R1-1239082247-32.txt.gz
grupo 06 -> H-H1_GWOSC_4KHZ_R1-1249852241-32.txt.gz
grupo 07 -> L-L1_GWOSC_4KHZ_R1-1186741846-32.txt.gz
grupo 08 -> L-L1_GWOSC_4KHZ_R1-1187008867-32.txt.gz
grupo 09 -> L-L1_GWOSC_4KHZ_R1-1239082247-32.txt.gz
grupo 10 -> L-L1_GWOSC_4KHZ_R1-1240215487-32.txt.gz
grupo 11 -> L-L1_GWOSC_4KHZ_R1-1249852241-32.txt.gz
grupo 12 -> V-V1_GWOSC_4KHZ_R1-1186741846-32.txt.gz
grupo 13 -> V-V1_GWOSC_4KHZ_R1-1187008867-32.txt.gz
grupo 14 -> V-V1_GWOSC_4KHZ_R1-1239082247-32.txt.gz
grupo 15 -> V-V1_GWOSC_4KHZ_R1-1240215487-32.txt.gz
grupo 16 -> V-V1_GWOSC_4KHZ_R1-1249852241-32.txt.gz
grupo 17 -> L-L1_GWOSC_4KHZ_R1-1186741846-32.txt.gz
grupo 18 -> L-L1_GWOSC_4KHZ_R1-1187008867-32.txt.gz
grupo 19 -> L-L1_GWOSC_4KHZ_R1-1239082247-32.txt.gz
grupo 20 -> L-L1_GWOSC_4KHZ_R1-1240215487-32.txt.gz
grupo 21 -> G-G1_GWOSC_4KHZ_R1-1187008867-32.txt.gz
grupo 22 -> H-H1_GWOSC_4KHZ_R1-1126259447-32.txt.gz
grupo 23 -> H-H1_GWOSC_4KHZ_R1-1186741846-32.txt.gz
grupo 24 -> H-H1_GWOSC_4KHZ_R1-1187008867-32.txt.gz
grupo 25 -> H-H1_GWOSC_4KHZ_R1-1239082247-32.txt.gz

